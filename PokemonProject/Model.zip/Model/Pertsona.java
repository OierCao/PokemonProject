package Pokemon.Model;

public class Pertsona extends Jokalari {
	
	//Eraikitzaile
	public Pertsona(int pJokNum,int pPokKop)
	{
		super(pPokKop);
		izena = "Pertsona" + pJokNum;
	}
	
	//Beste metodoak
	public void jolastu() {}
}