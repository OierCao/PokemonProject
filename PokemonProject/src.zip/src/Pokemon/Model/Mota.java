package Pokemon.Model;

public enum Mota {
	Fire, Grass, Electric, Water;
}

