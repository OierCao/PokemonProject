package Pokemon.Model;

public class Pertsona extends Jokalari {
	
	//BUILDER
	public Pertsona(int pJokNum,int pPokKop)
	{
		super(pPokKop);
		izena = this.getClass().getName() + pJokNum;
	}
	
	
	
	//SET/GET
		
	
	//EXTRAS
	public void jolastu() {
		setTxanda(true);
		Jokalari erasotua = null;
		//LOOP mugimendu guztiak
		//{
		
		
		//nork eraso egin
		
		//nor erasotua
			//aukeratu bizirik dagoen norbait eta ahulduta ez dagoen pokemon bat
		
		//this.eguneratuErasotua(erasotua);
		
		//}
		
		setTxanda(false);
	}
	
	
}